// priority: 0

// console.info("Hello, World! (You will see this line every time server resources reload)")

ServerEvents.recipes( event => {
	// Change recipes here

	const REMOVED_ITEMS = ["kibe:wooden_bucket", "kibe:water_wooden_bucket", "kibe:water_ring", "kibe:magma_ring", "kibe:light_ring", "kibe:escape_rope", "kibe:fluid_hopper", "kibe:placer", "kibe:breaker", "kibe:drawbridge", "kibe:igniter", "kibe:redstone_timer", "kibe:vacuum_hopper", "kibe:heater", "kibe:dehumidifier", "kibe:chunk_loader", "kibe:stone_spikes", "kibe:iron_spikes", "kibe:gold_spikes", "kibe:diamond_spikes", "kibe:cobblestone_generator_mk1", "kibe:cobblestone_generator_mk2", "kibe:cobblestone_generator_mk3", "kibe:cobblestone_generator_mk4", "kibe:cobblestone_generator_mk5", "kibe:basalt_generator_mk1", "kibe:basalt_generator_mk2", "kibe:basalt_generator_mk3", "kibe:basalt_generator_mk4", "kibe:basalt_generator_mk5", "kibe:regular_conveyor_belt", "kibe:fast_conveyor_belt", "kibe:express_conveyor_belt", "kibe:white_elevator", "kibe:orange_elevator", "kibe:magenta_elevator", "kibe:light_blue_elevator", "kibe:yellow_elevator", "kibe:lime_elevator", "kibe:pink_elevator", "kibe:gray_elevator", "kibe:light_gray_elevator", "kibe:cyan_elevator", "kibe:blue_elevator", "kibe:purple_elevator", "kibe:green_elevator", "kibe:brown_elevator", "kibe:red_elevator", "kibe:black_elevator", "farmersdelight:oak_cabinet", "farmersdelight:birch_cabinet", "farmersdelight:spruce_cabinet", "farmersdelight:dark_oak_cabinet", "farmersdelight:jungle_cabinet", "farmersdelight:crimson_cabinet", "farmersdelight:warped_cabinet", "farmersdelight:acacia_cabinet"];

	let i = 0;
	let text = "";

	while (REMOVED_ITEMS[i]) {
		text = REMOVED_ITEMS[i];
		event.remove({ output: text })
		i++;
	}

	//remove default recipe for chisel as it conflicts with veggie_way:knife
	event.remove({ output: "chisel:chisel" })

	// Add shaped recipe for chisel
	event.shaped("chisel:chisel", [
		"I",
		"S"
	], {
		I: "minecraft:iron_ingot",
		S: "minecraft:stick"
	})

})

// Listen to player login event
PlayerEvents.loggedIn( event => {
	// Check if player doesn"t have "starting_items" stage yet
	if (!event.player.stages.has("starting_items")) {
		// Add the stage
		event.player.stages.add("starting_items")
		// Give some items to player
		event.player.give("minecraft:stone_sword")
		event.player.give("minecraft:stone_pickaxe")
		event.player.give("minecraft:stone_axe")
		event.player.give("16x minecraft:cooked_beef")
	}
})